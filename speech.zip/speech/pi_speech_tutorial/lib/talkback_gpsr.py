#!/usr/bin/env python

"""
    talkback.py - Say back what is heard by the pocketsphinx recognizer.
"""

import roslib; roslib.load_manifest('pi_speech_tutorial')
import rospy
from std_msgs.msg import String

from sound_play.libsoundplay import SoundClient

class TalkBack:
      
    def __init__(self):
        rospy.on_shutdown(self.cleanup)
        self.voice = rospy.get_param("~voice", "voice_don_diphone")
        self.wavepath = rospy.get_param("~wavepath", "")
        self.command = ['','','','']
        self.keywords_to_command_items = {'ITEMS': ['chips','biscuits','original-pringles','lemon-pringles','cheese','seafood','cornflakes','milk','green tea','beer','lemonade','milo','water','yoghurt','seven-up','spoons','metal-cup','red-cup','glass','paper-cup','snacks','food','drinks','kitchenary']}
        self.keywords_to_command_locations1 = {'LOCATIONS': ['couch-table','sideboard','dinning-table','kitchen-table','stove','sofa','toilet','armchair','bed','bookshelf','drawer','closet','cupboard','front-door','back-door','TV','washing-machine','fridge']}
	self.keywords_to_command_locations2 = {'LOCATIONS': ['me','him','her']}
        self.keywords_to_command_names ={'NAMES':['michael','christopher','matthew','joshua','david','james','daniel','Robert','John','Joseph','Jessica','Jennifer','Amanda','Ashley','Sarah','Stephanie','Melissa','Nicole','Elizabeth','Heather']}
        # Create the sound client object
        self.soundhandle = SoundClient()
        rospy.sleep(1)
        self.soundhandle.stopAll()
        # Announce that we are ready for input
        self.soundhandle.playWave(self.wavepath + "/R2D2a.wav")
        rospy.sleep(1)
        self.soundhandle.say("Ready", self.voice)
        
        # rospy.loginfo("Say one of the navigation commands...")

        self.gpsr_location1 = rospy.Publisher('gpsr_location1', String, queue_size=10)
	self.gpsr_location2 = rospy.Publisher('gpsr_location2', String, queue_size=10)
	self.gpsr_name = rospy.Publisher('gpsr_name', String, queue_size=10)
	self.gpsr_item = rospy.Publisher('gpsr_item', String, queue_size=10)
        # rospy.init_node('command', anonymous=True)

        # Subscribe to the recognizer output
        rospy.Subscriber('recognizer_output', String, self.talkback)

    def get_command_items(self, data):
        for (command, keywords) in self.keywords_to_command_items.iteritems():
            for word in keywords:
                if data.find(word) > -1:
                    return word
            return 'None'

    def get_command_locations1(self, data):
        for (command, keywords) in self.keywords_to_command_locations1.iteritems():
            for word in keywords:
                if data.find(word) > -1:
                    return word
            return 'None'
    def get_command_locations2(self, data):
        for (command, keywords) in self.keywords_to_command_locations2.iteritems():
            for word in keywords:
                if data.find(word) > -1:
                    return word
            return 'None'
 
    def get_command_names(self, data):
        for (command, keywords) in self.keywords_to_command_names.iteritems():
            for word in keywords:
                if data.find(word) > -1:
                    return word
            return 'None'

    def delete_none(self,data):
         for k in range(len(data)): 
            if data[k]== '':
                del data[k]



    def talkback(self, msg):
        # Print the recognized words on the screen
        rospy.loginfo(msg.data)
        msg.data = msg.data.lower()
	print msg.data
        # print msg.data
        # Speak the recognized words in the selected voice
        # self.soundhandle.say(msg.data, self.voice)
        # content = msg.data
        
        # global command[5]
        # if command == None
        self.command[0] = location1 = self.get_command_locations1(msg.data)
        self.command[1] = location2 = self.get_command_locations2(msg.data)
	self.command[2] = item = self.get_command_items(msg.data)
	self.command[3] = name = self.get_command_names(msg.data)
        # content = msg.data.split(' ')
        # print content
        # self.delete_none(content)
        print 'item = ' + item
        print 'location1 = ' + location1
	print 'location2 = ' + location2
        print 'name = ' + name
        print self.command
        # print rospy.get_time()
        self.gpsr_location1.publish(self.command[0])
	self.gpsr_location2.publish(self.command[1])
	self.gpsr_item.publish(self.command[2])
	self.gpsr_name.publish(self.command[3])
        # print command
        # Uncomment to play one of the built-in sounds
        #rospy.sleep(2)
        #self.soundhandle.play(5)
        
        # Uncomment to play a wave file
        #rospy.sleep(2)
        #self.soundhandle.playWave(self.wavepath + "/R2D2a.wav")

    def cleanup(self):
        rospy.loginfo("Shutting down talkback node...")

if __name__=="__main__":
    rospy.init_node('talkback')
    try:
        TalkBack()
        rospy.spin()
    except:
        pass

    pub = rospy.Publisher('chatter', String, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        hello_str = "hello world %s" % rospy.get_time()
        rospy.loginfo(hello_str)
        pub.publish(hello_str)
        rate.sleep()
